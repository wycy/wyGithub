package com.example.administrator.fragmentunit.activitys;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.design.widget.TabLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.administrator.fragmentunit.R;
import com.example.administrator.fragmentunit.fragment.FragmentFour;
import com.example.administrator.fragmentunit.fragment.FragmentOne;
import com.example.administrator.fragmentunit.fragment.FragmentThree;
import com.example.administrator.fragmentunit.fragment.FragmentTwo;

import butterknife.Bind;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {
    @Bind(R.id.toolbar_title)
    TextView toolbar_title;
    @Bind(R.id.mid_toolbar)
    Toolbar toolbar;
    @Bind(R.id.menu_layout)
    TabLayout tabmenu;


    private ImageView homeImg1;
    private ImageView homeImg2;
    private ImageView homeImg3;
    private ImageView homeImg4;

    private FragmentOne fragmentOne;
    private FragmentTwo fragmentTwo;
    private FragmentThree fragmentThree;
    private FragmentFour fragmentFour;

    private String[] dataMenu = {"home1", "home2", "home3", "home4"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //init toolbar
        ButterKnife.bind(this);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
//      getSupportActionBar().setHomeAsUpIndicator(R.drawable.app_back);
        toolbar_title.setText("FragmentMoudle");

        //menudata
        for (int i = 0; i < dataMenu.length; i++) {
            View view = View.inflate(this, R.layout.custom_tab, null);
            view.setTag(dataMenu[i].toString());
            TextView tv_tabmenu_name = (TextView) view.findViewById(R.id.tv_menu);
            tv_tabmenu_name.setText(dataMenu[i].toString());
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            params.weight = 1;
            view.setLayoutParams(params);

            //set icon
            if (i == 0) {
                homeImg1 = (ImageView) view.findViewById(R.id.icon);
                homeImg1.setBackgroundResource(R.mipmap.home_s);
            } else if (i == 1) {
                homeImg2 = (ImageView) view.findViewById(R.id.icon);
                homeImg2.setBackgroundResource(R.mipmap.home);
            } else if (i == 2) {
                homeImg3 = (ImageView) view.findViewById(R.id.icon);
                homeImg3.setBackgroundResource(R.mipmap.home);
            } else if (i == 3) {
                homeImg4 = (ImageView) view.findViewById(R.id.icon);
                homeImg4.setBackgroundResource(R.mipmap.home);
            }
            //add Tab
            tabmenu.addTab(tabmenu.newTab().setCustomView(view));
        }

        initTabMenuClick();
        initFragment();
    }

    private void initFragment() {
        FragmentManager fm = getFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        if(fragmentOne==null){
            fragmentOne =   new FragmentOne();
        }
        ft.replace(R.id.layout_fragment, fragmentOne);
        ft.commit();
    }

    private void initTabMenuClick() {
        tabmenu.setOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                FragmentManager fm = getFragmentManager();
                FragmentTransaction ft = fm.beginTransaction();
                if (tab.getCustomView().getTag().equals(dataMenu[0])) {
                    if (fragmentOne == null) {
                        fragmentOne = new FragmentOne();
                    }
                    ft.replace(R.id.layout_fragment, fragmentOne);
                    toolbar_title.setText("FragmentMoudle");
                    setImgChange(dataMenu[0]);
                } else if (tab.getCustomView().getTag().equals(dataMenu[1])) {
                        if (fragmentTwo == null) {
                            fragmentTwo = new FragmentTwo();
                        }
                        ft.replace(R.id.layout_fragment, fragmentTwo);
                        toolbar_title.setText("Home2");
                        setImgChange(dataMenu[1]);
                    } else if (tab.getCustomView().getTag().equals(dataMenu[2])) {
                        if (fragmentThree == null) {
                            fragmentThree = new FragmentThree();
                        }
                        ft.replace(R.id.layout_fragment, fragmentThree);
                        toolbar_title.setText("Home3");
                        setImgChange(dataMenu[2]);
                    } else if (tab.getCustomView().getTag().equals(dataMenu[3])) {
                        if (fragmentFour == null) {
                            fragmentFour = new FragmentFour();
                        }
                        ft.replace(R.id.layout_fragment, fragmentFour);
                        toolbar_title.setText("Home4");
                        setImgChange(dataMenu[3]);
                    }

                    ft.commit();

                }

                @Override
                public void onTabUnselected (TabLayout.Tab tab){

                }

                @Override
                public void onTabReselected (TabLayout.Tab tab){

                }
            }

            );
        }


    private void setImgChange(String tag) {
        if (tag.equals(dataMenu[0])) {
            homeImg1.setBackgroundResource(R.mipmap.home_s);
            homeImg2.setBackgroundResource(R.mipmap.home);
            homeImg3.setBackgroundResource(R.mipmap.home);
            homeImg4.setBackgroundResource(R.mipmap.home);
        } else if (tag.equals(dataMenu[1])) {
            homeImg1.setBackgroundResource(R.mipmap.home);
            homeImg2.setBackgroundResource(R.mipmap.home_s);
            homeImg3.setBackgroundResource(R.mipmap.home);
            homeImg4.setBackgroundResource(R.mipmap.home);
        } else if (tag.equals(dataMenu[2])) {
            homeImg1.setBackgroundResource(R.mipmap.home);
            homeImg2.setBackgroundResource(R.mipmap.home);
            homeImg3.setBackgroundResource(R.mipmap.home_s);
            homeImg4.setBackgroundResource(R.mipmap.home);
        } else if (tag.equals(dataMenu[3])) {
            homeImg1.setBackgroundResource(R.mipmap.home);
            homeImg2.setBackgroundResource(R.mipmap.home);
            homeImg3.setBackgroundResource(R.mipmap.home);
            homeImg4.setBackgroundResource(R.mipmap.home_s);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * toolbar back
     *
     * @return
     */
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
